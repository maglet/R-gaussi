#Using R as a calculator

1+100

#Order of operations
3+5*2 

############Is different from
(3+5)*2

#The 3 following are the same
(3+(5*(2^6))) #hard to read
3+5*2^2       #clear, but need to know the tiles
3+5*(2^2)     #if you forget some rules, this might help

#Everything after the hash (#) symbol is ignored by R

################# Mathematicsl functions ################
# Function: predefined chunks of code
########## Take input
########## Return output
########## Can be built in, defined in packages, or home made

sin(1) #trigonometry

log(1) #natural log

log10(1) #log base 10 

exp(0.5) #same as e^(.5)

### To find out more about a function: 

?exp

########## Comparing things #############################
##### Requires an operator (==, !=, <, >, <=, >=)
##### Compares values on either side of operator
##### Returns TRUE or FALSE (boolean values)

1 == 1 #equal to (two equal signs)

1!=2   #not equal to

1<2    #less than

1<=1   # less than or equal to 

1>0    #greater than

1>=-9   # greater than or equal to 

########## Variables and assignment #####################
#### Variables hold values
#### use the assignment operator (<-)

x<-1/40 #Assigns the value 1/40 (decimal) to the variable x

x       #prints the value of the variable

log(x)  #prints the value to the screen because 
          #it wasn't assigned to a variable

x<-100  #values of variables can be changed

x

x<-x+1  #variable can be used when assigning a new value

############ Challenge 1

#What will be the value of each variable after each statement in the following 
#program?

mass <- 47.5
age <- 122
mass <- mass * 2.3
age <- age - 20

########### Challenge 2

#Run the code from the previous challenge, and write a command to compare mass 
#to age. Is mass larger than age?

############ Managing your environment

ls() #lists all the variables in your working space

rm(x) #removes the variable x from the environment

rm(list=ls()) #removes all the variables

############ Challenge 3
#Clean up your working environment by deleting the mass and age variables.

############## Packages #############################

install.packages() #See all installed packages

install.packages("ggplot2") #installs the ggplot2 package

update.packages() #updates installed packages

remove.packages("ggplot2") #removes the ggplot2 package

library(ggplot2) # loads the ggplot2 package
                    #needs to be loaded every time you start R

