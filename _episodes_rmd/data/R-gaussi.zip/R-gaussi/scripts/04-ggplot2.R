# read the data
gapminder <- read.csv("data/gapminder-FiveYearData.csv")

#load the dplyr package
library(ggplot2)

#Plot gdp per capita by life expectancy
# 3 Elements to this code: 
ggplot(data = gapminder,                    #data
       aes(x = gdpPercap, y = lifeExp)) +   #aesthetics
          geom_point()                      #geoms

# Just the data: opens plot window
ggplot(data = gapminder)                    #data

# Data and aesthetics: plot with axes 
ggplot(data = gapminder,                    #data
       aes(x = gdpPercap, y = lifeExp))     #aesthetics

# Add geoms: the whole plot
ggplot(data = gapminder,                    #data
       aes(x = gdpPercap, y = lifeExp)) +   #aesthetics
          geom_point()                      #geoms

############ Challenge 1: 
#Modify the example so that the figure shows how life expectancy has changed 
#over time:
          
          ggplot(data = gapminder, aes(x = gdpPercap, y = lifeExp)) + 
                    geom_point()

#Hint: the gapminder dataset has a column called “year”, which should appear on 
          #the x-axis.
          
############ Layers
#plot lines instead of points

ggplot(data = gapminder, aes(x=year, y=lifeExp, by=country, color=continent)) +
          geom_line()

#do lines and points
ggplot(data = gapminder, aes(x=year, y=lifeExp, by=country, color=continent)) +
          geom_line() + 
          geom_point()

#color only lines, not points

ggplot(data = gapminder, aes(x=year, y=lifeExp, by=country)) +
          geom_line(aes(color=continent)) +
          geom_point()

########## Challenge 3

#Switch the order of the point and line layers from the previous example.
#What happened?

######### Transformations and statistics

#Back to example #1
ggplot(data = gapminder, aes(x = gdpPercap, y = lifeExp, color=continent)) +
          geom_point()

# plot on a log scale

ggplot(data = gapminder, aes(x = gdpPercap, y = lifeExp)) +
          geom_point(alpha = 0.5) + scale_x_log10()

# Add a linear model

ggplot(data = gapminder, aes(x = gdpPercap, y = lifeExp)) +
          geom_point() + scale_x_log10() + geom_smooth(method="lm")

# make the line thicker

ggplot(data = gapminder, aes(x = gdpPercap, y = lifeExp)) +
          geom_point() + scale_x_log10() + geom_smooth(method="lm", size=1.5)

########## Challenge 3a

#Modify the color and size of the points on the point layer in the previous example.

#Hint: do not use the aes function.

########## Challenge 3b

#Modify your solution to Challenge 4a so that the points are now a different 
#shape and are colored by continent with new trendlines. 

#Hint: The color argument can be used inside the aesthetic.

