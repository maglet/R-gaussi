# read the data
gapminder <- read.csv("data/gapminder-FiveYearData.csv")

#load the dplyr package
library(dplyr)

#Pick specific columns: select
###### Specify the data frame
###### List the columns you want to KEEP
###### Output: a new df with only those cols
year_country_gdp<- select(gapminder, year, country, gdpPercap)

# Another syntax to do the same thing: pipes (%>%)
######## Allows you to string dplyr commands together

year_country_gdp <- gapminder %>% 
          select(year,country,gdpPercap)

#Pick specific rows: filter
year_country_gdp_euro <- gapminder %>%
          filter(continent=="Europe") %>%
          select(year,country,gdpPercap)

############## Challenge 1

#Write a single command (which can span multiple lines and includes pipes) that 
#will produce a dataframe that has the African values for lifeExp, country and 
#year, but not for other Continents. How many rows does your dataframe have and 
#why?

# Make subtables within your df: group_by

str(gapminder)

str(gapminder%>%group_by(continent))

#Calculate summary statistics for a grouped table: summarize

gdp_bycontinents <- gapminder %>%
          group_by(continent) %>%
          summarize(mean_gdpPercap=mean(gdpPercap))

############ Challenge 2

#Calculate the average life expectancy per country. Which has the longest 
#average life expectancy and which has the shortest average life expectancy?

#Group by multiple variables:
gdp_bycontinents_byyear <- gapminder %>%
          group_by(continent,year) %>%
          summarize(mean_gdpPercap=mean(gdpPercap))

# Make multiple new variables with summarize

gdp_pop_bycontinents_byyear <- gapminder %>%
          group_by(continent,year) %>%
          summarize(mean_gdpPercap=mean(gdpPercap),
                    sd_gdpPercap=sd(gdpPercap),
                    mean_pop=mean(pop),
                    sd_pop=sd(pop))

# Count records: count()

gapminder %>%
          filter(year == 2002) %>%
          count(continent, sort = TRUE)

# use # records in calculations n()
gapminder %>%
          group_by(continent) %>%
          summarize(se_pop = sd(lifeExp)/sqrt(n()))

#Make a new column based on col values: mutate

gapminder %>%
          mutate(gdp_billion=gdpPercap*pop/10^9)

# More complicataed example
gdp_pop_bycontinents_byyear <- gapminder %>%
          mutate(gdp_billion=gdpPercap*pop/10^9) %>%
          group_by(continent,year) %>%
          summarize(mean_gdpPercap=mean(gdpPercap),
                    sd_gdpPercap=sd(gdpPercap),
                    mean_pop=mean(pop),
                    sd_pop=sd(pop),
                    mean_gdp_billion=mean(gdp_billion),
                    sd_gdp_billion=sd(gdp_billion))
