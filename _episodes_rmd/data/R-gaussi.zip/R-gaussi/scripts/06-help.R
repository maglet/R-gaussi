# Reading help files for functions
?read.csv
help(read.csv)

# For operators

?"+"

### Help for packages

vignette() #all vignettes
vignette(package="dplyr") # all vignettes for a package
vignette("data_frames")  #opens the named vignette

# can't remember the exact function name
??read

#dump the data you’re working with into a format so that it can be copy and 
#pasted by anyone else into their R session.
dput(gapminder, file = "dput.txt")

#print out your current version of R, as well as any packages you have loaded. 
#This can be useful for others to help reproduce and debug your issue.
sessionInfo()
