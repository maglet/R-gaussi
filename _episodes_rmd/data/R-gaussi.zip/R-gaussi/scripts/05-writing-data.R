# read the data
gapminder <- read.csv("data/gapminder-FiveYearData.csv")

#load the dplyr package
library(ggplot2)

ggsave("Most_recent.pdf")

# go directly to file, not to plot window

#turn on the pdf "device"
pdf("Life_Exp_vs_time.pdf", width=12, height=4)

#specify what goes in the image
ggplot(data=gapminder, aes(x=year, y=lifeExp, colour=country)) +
          geom_line()

# You then have to make sure to turn off the pdf device!
dev.off()

########## Challenge 1
# Rewrite your 'pdf' command to print to a png 
# file (hint: use `png()` function).

# Write data frame to file

aust_subset <- gapminder[gapminder$country == "Australia",]

write.table(aust_subset,
            file="cleaned-data/gapminder-aus.csv",
            sep=","
)

# Remove quotes and row names

write.table(
          gapminder[gapminder$country == "Australia",],
          file="cleaned-data/gapminder-aus.csv",
          sep=",", quote=FALSE, row.names=FALSE
)

########## Challenge 2
#Write a data-cleaning script file that subsets the gapminder data to include 
#only data points collected since 1990.

#Use this script to write out the new subset to a file in the cleaned-data/ 
#directory.
