# How to load a data table into R: read.csv
####### Input: file name and location
####### Output: a data frame
####### Assigns to the variable gapminder

gapminder <- read.csv("data/gapminder-FiveYearData.csv")

# Look at data frame structure: str
######## See a mix of text columns (factor) and numbers (int or num)
str(gapminder)

# how many rows and columns?
length(gapminder)
nrow(gapminder)
ncol(gapminder)
dim(gapminder)

# What are the columns called?
colnames(gapminder)

#preview of the top 6 rows

head(gapminder)

############### Challenge 1 ####################
#Read the output of str(gapminder) again; this time, use what you’ve learned 
#about factors, lists and vectors, as well as the output of functions like 
#colnames and dim to explain what everything that str prints out for gapminder 
#means. If there are any parts you can’t interpret, discuss with your neighbors!

########### Subsetting 

#Isolate the life expectancy (5th) column
#store it in a variable x 
x<- gapminder[,5]

# look at the third element
x[3]

# Concatenate function c()

c(1,3) #makes a vector with values 1 and 3

x[c(1,3)] #returns the first and third element

# Ranges of numbers (: operator)

1:4 #vector with numbers 1 - 4

x[1:4] #returns first 4 elements of x

x[c(1,2,3,4)] #same thing

x[1800] #returns NA if it's outside the range

############# Subsetting data frames ###############

#Specify a column
gapminder[1]

#specify one data point: [row,col]
gapminder[3,1]

#entire row: leave col blank
gapminder[3,]

#another way to select an entire column
gapminder[,1]

#Range of rows
gapminder[1:3,]

#specific rows
gapminder[c(1,3)]

################### Challenge 2
#Why does gapminder[1:20] return an error? How does it differ from gapminder[1:20, ]?

#Create a new data.frame called gapminder_small that only contains rows 1 
#through 9 and 19 through 23. You can do this in one or two steps.

############# Subsetting by name ######################

names(gapminder)

#put the column name in quotes or double brackets
head(gapminder[["lifeExp"]])

#or use the $ operator
head(gapminder$year)